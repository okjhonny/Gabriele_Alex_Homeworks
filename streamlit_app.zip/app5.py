import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Dashboard", layout="wide")

@st.cache_data
def build_fact_table(dim_symbol: pd.DataFrame, dim_geo: pd.DataFrame, fact_transactions: pd.DataFrame) -> pd.DataFrame:
    """
    clean thedate, add unknown on the missing information about symbol whithout correspondect in symbol_dim,
    create the surrogate keys and the final fact table
    """
    dim_symbol = dim_symbol.copy()
    dim_geo = dim_geo.copy()
    fact_transactions = fact_transactions.copy()

    # --- CLEANING THE NAME OF SOME COUNTRY ---
    dim_geo.loc[dim_geo['name'].str.contains('Taiwan', na=False), 'name'] = 'Taiwan'
    dim_geo.loc[dim_geo['name'].str.contains('Tür', na=False), 'name'] = 'Turkey'
    
    correzioni_paesi = {
        'United Kingdom of Great Britain and Northern Ireland': 'United Kingdom',
        'United States of America': 'United States',
        'Netherlands, Kingdom of the': 'Netherlands',
        'Virgin Islands (British)': 'British Virgin Islands'
    }
    dim_geo['name'] = dim_geo['name'].replace(correzioni_paesi)

    # --- MANAGING THE MISSMATCHED SYMBOLS  (STUB RECORDS) ---
    valid_symbols = set(dim_symbol['symbol'].dropna().unique())
    fact_transactions.columns = fact_transactions.columns.str.strip()
    fact_transactions['Symbol'] = fact_transactions['Symbol'].replace('AGO.L', 'AGO')
    transaction_symbols = set(fact_transactions['Symbol'].dropna().unique())
    
    missing_symbols = transaction_symbols - valid_symbols 

    if missing_symbols:
        stub_records = []
        for sym in missing_symbols:
            stub_records.append({
                'symbol': sym,
                'company_name': 'Unknown', 
                'sector': 'Unknown', 
                'industry': 'Unknown', 
                'country': 'Unknown' 
            })
        
        missing_symbols_df = pd.DataFrame(stub_records)
        dim_symbol = pd.concat([dim_symbol, missing_symbols_df], ignore_index=True)

    # --- the news surrogate keys ---
    dim_symbol = dim_symbol.reset_index(drop=True)
    dim_symbol['symbol_key'] = dim_symbol.index + 1

    dim_geo = dim_geo.reset_index(drop=True)
    dim_geo['geo_key'] = dim_geo.index + 1

    # --- TRASFORM THE DATE DATA TO ASK MORE PRECISE QUERIES ---
    if 'Date' in fact_transactions.columns:
        fact_transactions['Date'] = pd.to_datetime(fact_transactions['Date'], format="%d/%m/%Y %H:%M:%S", errors='coerce')
        fact_transactions['year'] = fact_transactions['Date'].dt.year


    df = fact_transactions.merge(
        dim_symbol[['symbol', 'symbol_key', 'country', 'company_name', 'sector', 'industry']], 
        left_on='Symbol', 
        right_on='symbol', 
        how='left'
    )
    df = df.drop(columns=['symbol'])

    df = df.merge(
        dim_geo[['name', 'geo_key']], 
        left_on='country', 
        right_on='name', 
        how='left'
    )
    df = df.drop(columns=['name'])
    
    df.columns = df.columns.str.lower()
    return df 

#-----------------------------------------------------------------

# ==========================================
# PAGE 2 ANOMALY DETECTION  EXTRA PAGE
# ==========================================
def page_2_anomaly_detection(df):
    """
    Renders Page 2 for Volume Anomaly Detection.
    It takes the main DataFrame (df) as input.
    """
    st.subheader("2. Volume Anomalies (Spikes)")
    st.markdown("""
    We are looking for individual trades where the volume of traded shares (`unit`) 
    deviates heavily from the usual behavior. Use the filters below to isolate suspicious cases.
    """)

    # Ensure a date-only column exists for the bar chart grouping at the end
    if 'date_only' not in df.columns:
        df['date_only'] = df['date'].dt.date

    # --- DYNAMIC FILTERS ---
    col1, col2, col3 = st.columns(3)

    with col1:
        # Filter by Symbol
        available_symbols = sorted(df['symbol'].dropna().unique().tolist())
        selected_symbols = st.multiselect("🎯 Filter by Symbol", available_symbols, default=available_symbols)

    with col2:
        # Filter by Transaction Type
        available_types = sorted(df['transactiontype'].dropna().unique().tolist())
        selected_types = st.multiselect("🔄 Transaction Type", available_types, default=available_types)

    with col3:
        # Dynamic Multiplier (Replaces the fixed threshold)
        anomaly_threshold = st.slider("⚠️ Anomaly Sensitivity (x Times the Mean)", min_value=1.5, max_value=10.0, value=2.0, step=0.5)

    # --- APPLY FILTERS ---
    mask = (df['symbol'].isin(selected_symbols)) & (df['transactiontype'].isin(selected_types))
    filtered_df = df[mask].copy()

    if filtered_df.empty:
        st.warning("No data matches the selected filters.")
        return # Stop execution if no data is left

    # Calculate the mean of traded shares for each symbol on the filtered data
    symbol_means = filtered_df.groupby('symbol')['unit'].mean().reset_index()
    symbol_means.rename(columns={'unit': 'unit_mean'}, inplace=True)
    
    # Merge the mean back into the dataframe
    anomaly_df = filtered_df.merge(symbol_means, on='symbol', how='left')
    
    # Identify anomalies using the dynamic slider value
    anomaly_df['is_anomaly'] = anomaly_df['unit'] > (anomaly_df['unit_mean'] * anomaly_threshold)
    
    # Extract the anomalous operations
    spikes = anomaly_df[anomaly_df['is_anomaly']]
    
    if not spikes.empty:
        st.error(f"🚨 Detected **{len(spikes)}** transactions with off-the-charts volumes!")
        
        # Summary Table
        columns_to_show = ['date', 'symbol', 'transactiontype', 'unit', 'unit_mean']
        # Safeguard to ensure we only select columns that actually exist in the dataframe
        columns_to_show = [col for col in columns_to_show if col in spikes.columns]
        
        spikes_display = spikes[columns_to_show].sort_values(by='unit', ascending=False)
        st.dataframe(spikes_display, use_container_width=True)
        
        # --- VIOLIN PLOT ---
        st.markdown("### 🎻 Volume Distribution")
        st.markdown("Red dots highlight transactions classified as anomalies based on your chosen sensitivity.")
        
        # The Violin plot shows density and overlays the points. Anomalies are colored distinctly.
        fig_violin = px.violin(
            anomaly_df, 
            x="symbol", 
            y="unit", 
            color="is_anomaly", 
            box=True,       # Show the internal boxplot
            points="all",   # Show all individual trades
            hover_data=['date', 'transactiontype'], # Extra data on hover
            color_discrete_map={True: "#d62728", False: "#1f77b4"} # Red for anomalies, blue for normal trades
        )
        
        fig_violin.update_layout(xaxis_title="Symbol", yaxis_title="Units Traded (Volume)")
        st.plotly_chart(fig_violin, use_container_width=True)
        
        # --- BAR CHART ---
        st.markdown("**Total Volume Time Trend**")
        # Group by the date-only column we ensured existed at the top
        volume_over_time = filtered_df.groupby('date_only')['unit'].sum()
        st.bar_chart(volume_over_time, color="#ff7f0e") 
        
    else:
        st.success(f"✅ With a sensitivity of **{anomaly_threshold}x**, volumes are regular and without extreme spikes.")
        
#-----------------------------------------------------------------


# --- LOAD DATA ---
df_sym = pd.read_csv('symbols.csv' , sep=';')
df_txn = pd.read_csv('account-statement-1-1-2024-12-31-2024.csv', sep=';')
df_geo = pd.read_csv('country.csv', sep=',')

df  = build_fact_table(df_sym, df_geo, df_txn)

# --- SIDEBAR NAVIGAZIONE ---
st.sidebar.title("MENU")
selected_page = st.sidebar.radio(
    "Scegli la pagina:",
    ["Page 1 - Time Analysis", "Page 2 - Anomaly Detection"]
)
st.sidebar.divider()

# --- PAGE 1 ---
if selected_page == "Page 1 - Time Analysis":
    st.title("📈 Page 1 - Time Analysis")
    st.sidebar.header("Filters")

    
    if isinstance(df, pd.DataFrame) and 'date' in df.columns:
        date_valide = df['date'].dropna()
        
        if not date_valide.empty:
            min_date = date_valide.min().date()
            max_date = date_valide.max().date()
            
            # date range is needed to make the slider works
            date_range = st.sidebar.slider("Select a valid range", min_value=min_date, max_value=max_date,value=(min_date, max_date), format='DD/MM/YYYY')
        else:
            st.error("Your date is not found in the column 'date'.")
            st.stop() 
    else:
        st.error("The column date is not found in the DataFrame")
        st.write(getattr(df, 'columns', 'Structural Error '))
        st.stop()
        
    type_transaction = st.sidebar.selectbox( 'Select the type of transaction are you interest in', 
                                                options=['ALL', 'BUY', 'SELL'],
                                                index = 0 ) # doing index = 0 the graph starts with all transactions
    # if the user imput the right range of date the slider will works correctly
    if len(date_range) == 2:
        start_date, end_date = date_range
        
        # due to the date_range i filter the dataset
        mask = (df['date'].dt.date >= start_date) & (df['date'].dt.date <= end_date)
        filtered_df = df.loc[mask]
        
        if type_transaction != 'ALL':
            filtered_df = filtered_df[filtered_df['transactiontype'] == type_transaction]
        
        # --- LINEAR GRAPH ---
        st.subheader("Total Number of Transactions & Volume Over Time (BUY + SELL)")
        trend_data = (
            filtered_df.groupby(filtered_df['date'].dt.date)
            .agg(
                Transactions =('date', 'size'),
                Total_Volume =('unit','sum')
            )
            .reset_index()
        )
        
        fig = make_subplots(specs=[[{"secondary_y": True}]]) # FOR THE VOLUME BAR

        fig.add_trace(
            go.Scatter(x=trend_data['date'], y=trend_data['Transactions'],  # THE TOTAL LEVEL OF TRANSACTION
                       name="Transaction", line=dict(color='#1f77b4')),
            secondary_y=False,
        )

        fig.add_trace(
            go.Scatter(x=trend_data['date'], y=trend_data['Total_Volume'],  # FOR THE VOLUME MOVED IN THE SAME DATE RANGE
                       name="Volume", line=dict(color='#d62728')),
            secondary_y=True,
        )

        fig.update_layout(title_text="Transaction vs Volume", hovermode="x unified")
        fig.update_yaxes(title_text="<b>Transaction</b>", secondary_y=False)
        fig.update_yaxes(title_text="<b>Volume</b>", secondary_y=True)

        st.plotly_chart(fig, use_container_width=True) 
        
        st.divider() 
        
        # --- BAR CHARTS ---
        col1, col2, col3 = st.columns(3)
        # bar chart showing the top 3 traded symbols by transaction count.
        with col1:
            st.subheader("Top 3 Symbols")
            top_symbols = filtered_df.groupby(['symbol', 'company_name', 'country', 'industry']).size().reset_index(name='Count') 
            top_symbols = top_symbols.sort_values(by='Count', ascending=False).head(3) 
            
            fig_sym = px.bar(
                top_symbols, x='symbol', y='Count', 
                color='Count', color_continuous_scale='inferno',
                text='Count', template="plotly_white",
                hover_data=['company_name', 'country', 'industry'] 
            )
            fig_sym.update_traces(
                textposition='outside', 
                hovertemplate="<b>Ticker:</b> %{x}<br><b>Transactions:</b> %{y}<br><br><b>Company:</b> %{customdata[0]}<br><b>Country:</b> %{customdata[1]}<br><b>Industry:</b> %{customdata[2]}<extra></extra>"
            )
            fig_sym.update_layout(coloraxis_showscale=False, xaxis_title="", yaxis_title="")
            st.plotly_chart(fig_sym, use_container_width=True)
        # bar chart showing the top 5 sectors by transaction count.    
        with col2:
            st.subheader("Top 5 Sectors")
            top_sectors = filtered_df.groupby('sector').agg( 
                Count=('sector', 'size'),
                Top_Country=('country', lambda x: x.mode()[0] if not x.empty else 'N/D')
            ).sort_values(by='Count', ascending=False).head(5).reset_index()
            
            fig_sec = px.bar(
                top_sectors, x='Count', y='sector', orientation='h',
                color='Count', color_continuous_scale='Teal',
                text='Count', template="plotly_white",
                hover_data=['Top_Country']
            )
            fig_sec.update_traces(
                textposition='inside', 
                hovertemplate="<b>Sector:</b> %{y}<br><b>Total Trades:</b> %{x}<br><b>Main Country:</b> %{customdata[0]}<extra></extra>"
            )
            fig_sec.update_layout(yaxis={'categoryorder':'total ascending'}, coloraxis_showscale=False, xaxis_title="", yaxis_title="")
            st.plotly_chart(fig_sec, use_container_width=True)
        # bar chart showing the top 5 industries by transaction count    
        with col3:
            st.subheader("Top 5 Industries")
            filtered_df_clean = filtered_df[filtered_df['industry']!= 'Unknown']
            top_industries = filtered_df_clean.groupby('industry').agg(
                Count=('industry', 'size'),
                Main_Sector=('sector', lambda x: x.mode()[0] if not x.empty else 'N/D')
            ).sort_values(by='Count', ascending=False).head(5).reset_index()
            
            fig_ind = px.bar(
                top_industries, x='Count', y='industry', orientation='h',
                color='Count', color_continuous_scale='Purp',
                text='Count', template="plotly_white",
                hover_data=['Main_Sector']
            )
            fig_ind.update_traces(
                textposition='inside', 
                hovertemplate="<b>Industry:</b> %{y}<br><b>Total Trades:</b> %{x}<br><b>Sector:</b> %{customdata[0]}<extra></extra>"
            )
            fig_ind.update_layout(yaxis={'categoryorder':'total ascending'}, coloraxis_showscale=False, xaxis_title="", yaxis_title="")
            st.plotly_chart(fig_ind, use_container_width=True)
            
    else:
        st.warning("Please select an End Date in the sidebar to view the charts.")

elif selected_page == "Page 2 - Anomaly Detection":
    page_2_anomaly_detection(df)